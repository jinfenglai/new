#!/usr/bin/env python3
"""Cross-platform build/flash/monitor helper for Flipper-Zero-ESP32-Port.

Replaces the legacy _winbuild_*.bat and _winbuild_monitor*.py scripts with a
single Python CLI. Originally Windows-only; cross-build is portable across
any OS that has ESP-IDF installed and Python 3.6+. The bash-side build.sh
is unaffected.

Usage examples:
    python winbuild.py setup                          # install ESP-IDF python env (rare)
    python winbuild.py check                          # verify env activates
    python winbuild.py build                          # build T-Embed CC1101 firmware
    python winbuild.py build --board waveshare_c6
    python winbuild.py flash --port COM14
    python winbuild.py monitor --duration 60          # stream live output
    python winbuild.py monitor --duration 15 --reset  # pulse DTR/RTS reset (UART bridges only)
    python winbuild.py all --port COM14               # build + flash + monitor (boot log captured)
    python winbuild.py cross-build                    # build for ALL supported boards in sequence
    python winbuild.py cross-build --boards t_embed waveshare_c6

Env vars (overridable):
    ESP_IDF_DIR  - path to ESP-IDF (default: C:\\Espressif\\frameworks\\esp-idf-v5.4.1)
    ESPPORT      - serial port (default: COM14)
"""

import argparse
import os
import re
import subprocess
import sys
import time
from pathlib import Path

DEFAULT_ESP_IDF_DIR = r"C:\Espressif\frameworks\esp-idf-v5.4.1"
DEFAULT_PORT = "COM14"
DEFAULT_DURATION = 8.0

# Mirrors build.sh board mapping.
BOARDS = {
    "cardputer":    ("m5stack_cardputer",     "esp32s3", "build_cardputer"),
    "cardputer_adv":("m5stack_cardputer_adv", "esp32s3", "build_cardputer_adv"),
}

REPO_ROOT = Path(__file__).resolve().parent


def get_esp_idf_dir() -> Path:
    p = Path(os.environ.get("ESP_IDF_DIR", DEFAULT_ESP_IDF_DIR))
    if not p.exists():
        sys.exit(
            f"ESP_IDF_DIR '{p}' does not exist. "
            "Set ESP_IDF_DIR or install ESP-IDF v5.4.x there.")
    return p


def get_port(arg_port):
    return arg_port or os.environ.get("ESPPORT", DEFAULT_PORT)


def env_for_idf(extra=None):
    env = os.environ.copy()
    env.pop("MSYSTEM", None)  # Git Bash detection breaks export.bat
    if extra:
        env.update(extra)
    return env


def run_with_idf_env(esp_idf_dir: Path, args: str, extra_env=None) -> int:
    # shell=True is required on Windows so cmd.exe parses the && and the quoted path
    # in `call "..."`; passing as a list mangles the quoting.
    cmd = f'call "{esp_idf_dir}\\export.bat" && idf.py {args}'
    return subprocess.run(cmd, shell=True, env=env_for_idf(extra_env), cwd=str(REPO_ROOT)).returncode


def cmd_setup(args):
    esp_idf_dir = get_esp_idf_dir()
    idf_tools = esp_idf_dir / "tools" / "idf_tools.py"
    if not idf_tools.exists():
        sys.exit(f"{idf_tools} not found.")
    # Match _winbuild_step1.bat: unset MSYSTEM, set IDF_PATH so idf_tools resolves
    # python_requirements.txt and friends from the right ESP-IDF tree.
    env = env_for_idf({"IDF_PATH": str(esp_idf_dir)})
    return subprocess.run(
        [sys.executable, str(idf_tools), "install-python-env"], env=env).returncode


def cmd_check(args):
    return run_with_idf_env(get_esp_idf_dir(), "--version")


def _sdkconfig_defaults_arg(flipper_board: str) -> str:
    """Build the -DSDKCONFIG_DEFAULTS argument for a board.

    ESP-IDF always loads `sdkconfig.defaults` plus the auto target variant
    `sdkconfig.defaults.<target>` (e.g. sdkconfig.defaults.esp32s3, which turns
    PSRAM on and sets 16 MB flash for T-Embed/generic S3). A board like the
    Cardputer has NO PSRAM and 8 MB flash, so it ships its own
    `sdkconfig.defaults.<flipper_board>` that must be applied LAST to override
    those. Without this the no-PSRAM Cardputer is configured for octal PSRAM
    and fails to boot. Boards with no per-board file keep the default behavior.
    """
    board_defaults = REPO_ROOT / f"sdkconfig.defaults.{flipper_board}"
    if board_defaults.exists():
        return f'-DSDKCONFIG_DEFAULTS="sdkconfig.defaults;sdkconfig.defaults.{flipper_board}"'
    return ""


def _merge_bin(build_dir: str, board_name: str, target: str):
    """Create a single merged .bin from bootloader + partition-table + app."""
    import json
    flasher_json = REPO_ROOT / build_dir / "flasher_args.json"
    if not flasher_json.exists():
        print(f"[merge] {flasher_json} not found, skipping merge.")
        return

    with open(flasher_json) as f:
        info = json.load(f)

    flash_settings = info.get("flash_settings", {})
    flash_mode = flash_settings.get("flash_mode", "dio")
    flash_size = flash_settings.get("flash_size", "8MB")
    chip = info.get("extra_esptool_args", {}).get("chip", target)

    # Build the merge_bin argument list: offset file pairs
    parts = []
    for offset, rel_path in sorted(info["flash_files"].items(), key=lambda x: int(x[0], 16)):
        abs_path = REPO_ROOT / build_dir / rel_path
        if not abs_path.exists():
            print(f"[merge] WARNING: {abs_path} not found, skipping merge.")
            return
        parts.extend([offset, str(abs_path)])

    out_name = f"Flipper-{board_name}-merged.bin"
    out_path = REPO_ROOT / out_name

    # esptool merge_bin via IDF env (esptool is on PATH after export.bat)
    merge_args = (
        f"--chip {chip} merge_bin "
        f"--flash_mode {flash_mode} --flash_size {flash_size} "
        f"-o \"{out_path}\" " + " ".join(parts)
    )
    esp_idf_dir = get_esp_idf_dir()
    cmd = f'call "{esp_idf_dir}\\export.bat" && esptool.py {merge_args}'
    rc = subprocess.run(cmd, shell=True, env=env_for_idf(), cwd=str(REPO_ROOT)).returncode
    if rc == 0:
        size_mb = out_path.stat().st_size / (1024 * 1024)
        print(f"[merge] Created {out_name} ({size_mb:.1f} MB)")
    else:
        print(f"[merge] esptool merge_bin failed (rc={rc})")


def cmd_build(args):
    flipper_board, target, build_dir = BOARDS[args.board]
    common = f"-B {build_dir} -DFLIPPER_BOARD={flipper_board} {_sdkconfig_defaults_arg(flipper_board)}".rstrip()
    esp_idf_dir = get_esp_idf_dir()
    # FLIPPER_BOARD must also be in the env: fam_config.py reads it via
    # os.environ to filter board-incompatible apps (e.g. NFC/IR on Waveshare C6).
    extra = {"FLIPPER_BOARD": flipper_board}
    rc = run_with_idf_env(esp_idf_dir, f"{common} set-target {target}", extra)
    if rc != 0:
        return rc
    rc = run_with_idf_env(esp_idf_dir, f"{common} reconfigure build", extra)
    if rc != 0:
        return rc
    # Generate merged binary (bootloader + partition-table + app → single .bin)
    _merge_bin(build_dir, args.board, target)
    return 0


def cmd_flash(args):
    flipper_board, _, build_dir = BOARDS[args.board]
    port = get_port(args.port)
    sdkconfig = _sdkconfig_defaults_arg(flipper_board)
    return run_with_idf_env(
        get_esp_idf_dir(),
        f"-B {build_dir} -DFLIPPER_BOARD={flipper_board} {sdkconfig} -p {port} flash".replace("  ", " "),
        {"FLIPPER_BOARD": flipper_board})


def _open_serial_clean(port, timeout_s=5.0):
    # Pre-pin DTR/RTS LOW before open so Windows' default assert-on-open
    # doesn't accidentally drive the chip into download mode. Retry through
    # USB re-enumeration windows.
    try:
        import serial
    except ImportError:
        sys.exit("pyserial not installed. Run: pip install pyserial")
    deadline = time.time() + timeout_s
    last_err = None
    while time.time() < deadline:
        try:
            s = serial.Serial()
            s.port = port
            s.baudrate = 115200
            s.timeout = 1
            s.dtr = False
            s.rts = False
            s.open()
            return s
        except serial.SerialException as e:
            last_err = e
            time.sleep(0.3)
    sys.exit(f"Could not open {port}: {last_err}")


def cmd_monitor(args):
    port = get_port(args.port)
    ser = _open_serial_clean(port)
    if args.reset:
        # DTR=False keeps IO0 high (normal-boot strap); RTS pulse asserts/releases EN.
        # Only works on USB-UART bridges, not on native USB-Serial/JTAG.
        ser.dtr = False
        ser.rts = True
        time.sleep(0.1)
        ser.rts = False
    start = time.time()
    try:
        while time.time() - start < args.duration:
            data = ser.read(4096)
            if data:
                sys.stdout.buffer.write(data)
                sys.stdout.buffer.flush()
    except KeyboardInterrupt:
        pass
    finally:
        ser.close()
    return 0


def cmd_all(args):
    rc = cmd_build(args)
    if rc != 0:
        return rc
    rc = cmd_flash(args)
    if rc != 0:
        return rc
    return cmd_monitor(args)


def _sdkconfig_target(path: Path):
    """Return CONFIG_IDF_TARGET="..." value from a sdkconfig file, or None."""
    try:
        text = path.read_text(errors='ignore')
    except OSError:
        return None
    m = re.search(r'^CONFIG_IDF_TARGET="([^"]+)"', text, re.MULTILINE)
    return m.group(1) if m else None


def _purge_stale_sdkconfig(target: str, build_dir: str):
    """Mirror build.sh: delete root sdkconfig and BUILD_DIR/sdkconfig if their
    cached CONFIG_IDF_TARGET doesn't match the target we're about to build.
    Without this, switching boards (esp32s3 → esp32c6) leaves a contaminated
    cmake cache and the next build fails with 'sdkconfig was generated for
    target X, but CMakeCache.txt contains Y'. """
    for p in (REPO_ROOT / "sdkconfig", REPO_ROOT / build_dir / "sdkconfig"):
        if not p.exists():
            continue
        cached = _sdkconfig_target(p)
        if cached and cached != target:
            print(f"[cross-build] {p.relative_to(REPO_ROOT)} is for {cached!r}, "
                  f"removing for {target!r}")
            p.unlink()


def cmd_cross_build(args):
    """Build firmware for every supported board in sequence. Verifies that
    a change doesn't break boards the developer can't physically test.

    Use --boards to limit the set. Builds are sequential — running two
    ESP-IDF builds in parallel against the same source tree contaminates
    the shared root sdkconfig and breaks both builds.
    """
    esp_idf_dir = get_esp_idf_dir()
    boards_to_build = args.boards if args.boards else list(BOARDS.keys())

    print(f"[cross-build] Building {len(boards_to_build)} board(s): "
          f"{', '.join(boards_to_build)}")

    results = {}
    for board in boards_to_build:
        if board not in BOARDS:
            print(f"\n[cross-build] Unknown board {board!r}, skipping "
                  f"(known: {', '.join(BOARDS.keys())})")
            results[board] = "unknown"
            continue

        flipper_board, target, build_dir = BOARDS[board]
        print(f"\n=== {board} ({target}, FLIPPER_BOARD={flipper_board}) ===")

        _purge_stale_sdkconfig(target, build_dir)

        common = f"-B {build_dir} -DFLIPPER_BOARD={flipper_board} {_sdkconfig_defaults_arg(flipper_board)}".rstrip()
        extra = {"FLIPPER_BOARD": flipper_board}

        rc = run_with_idf_env(esp_idf_dir, f"{common} set-target {target}", extra)
        if rc != 0:
            results[board] = f"set-target failed (rc={rc})"
            continue

        rc = run_with_idf_env(esp_idf_dir, f"{common} reconfigure build", extra)
        results[board] = "OK" if rc == 0 else f"build failed (rc={rc})"

    print("\n=== cross-build summary ===")
    failures = 0
    for board, status in results.items():
        # ASCII-only markers — Windows cmd.exe defaults to cp1252 and
        # crashes on Unicode glyphs in print().
        marker = "[OK]  " if status == "OK" else "[FAIL]"
        print(f"  {marker} {board}: {status}")
        if status != "OK":
            failures += 1

    if failures:
        print(f"\n[cross-build] {failures} board(s) failed.")
    else:
        print(f"\n[cross-build] All {len(results)} board(s) built successfully.")

    return 1 if failures else 0


def build_parser():
    p = argparse.ArgumentParser(
        prog="winbuild.py",
        description="Windows build/flash/monitor helper for Flipper-Zero-ESP32-Port.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Boards: " + ", ".join(BOARDS.keys()) + "\n"
            "Defaults: board=t_embed, port=$ESPPORT or COM14, duration=8s.\n"
            "Override ESP-IDF location via ESP_IDF_DIR env var.\n"
            "monitor does not reset by default; pass --reset on USB-UART bridges, or use\n"
            "`flash` (or `all`) to capture boot logs (flash performs a real hard reset)."))
    sub = p.add_subparsers(dest="command", required=True)

    sub.add_parser("setup", help="Install ESP-IDF python env (one-time)."
                   ).set_defaults(func=cmd_setup)
    sub.add_parser("check", help="Verify env activation + idf.py --version."
                   ).set_defaults(func=cmd_check)

    pb = sub.add_parser("build", help="Build firmware.")
    pb.add_argument("--board", choices=BOARDS, default="t_embed")
    pb.set_defaults(func=cmd_build)

    pf = sub.add_parser("flash", help="Flash firmware over USB.")
    pf.add_argument("--board", choices=BOARDS, default="t_embed")
    pf.add_argument("--port", default=None, help="Serial port (default: $ESPPORT or COM14)")
    pf.set_defaults(func=cmd_flash)

    pm = sub.add_parser("monitor", help="Stream serial output for N seconds.")
    pm.add_argument("--port", default=None, help="Serial port (default: $ESPPORT or COM14)")
    pm.add_argument("--duration", type=float, default=DEFAULT_DURATION,
                    help=f"Capture seconds (default: {DEFAULT_DURATION})")
    pm.add_argument("--reset", action="store_true",
                    help="Pulse DTR/RTS for a hard reset on attach "
                         "(USB-UART bridges only -- not supported on "
                         "ESP32-S3 native USB-Serial/JTAG)")
    pm.set_defaults(func=cmd_monitor)

    pa = sub.add_parser("all", help="build + flash + monitor.")
    pa.add_argument("--board", choices=BOARDS, default="t_embed")
    pa.add_argument("--port", default=None)
    pa.add_argument("--duration", type=float, default=DEFAULT_DURATION)
    # `flash` already performs a real hard reset via the ROM bootloader,
    # so the follow-up monitor never needs (and on USB-Serial/JTAG must not
    # attempt) its own reset pulse.
    pa.set_defaults(func=cmd_all, reset=False)

    pcb = sub.add_parser(
        "cross-build",
        help="Build for every supported board in sequence (cross-board "
             "compatibility check). Useful before opening a PR when the "
             "developer doesn't have all boards on hand to test.")
    pcb.add_argument(
        "--boards", nargs="*", choices=BOARDS, default=None,
        help=f"Subset of boards to build (default: all {len(BOARDS)}).")
    pcb.set_defaults(func=cmd_cross_build)

    return p


if __name__ == "__main__":
    args = build_parser().parse_args()
    sys.exit(args.func(args))
